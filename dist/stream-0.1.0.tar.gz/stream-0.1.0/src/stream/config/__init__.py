"""Configuration settings for the stream module."""
from .settings import Settings

__all__ = ["Settings"]
