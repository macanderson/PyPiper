import sys
import logging
import pprint

import attrs

from confluent_kafka import SerializingProducer
from confluent_kafka.serialization import StringSerializer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer
from confluent_kafka.admin import AdminClient

from stream.models.schema import AvroModel
from stream.config import Settings

__version_info__ = (1, 10, 0)
__version__ = "%s.%s.%s" % __version_info__

logger = logging.getLogger('Tradesignals-io')
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler(sys.stdout))
logger.addHandler(logging.FileHandler('./logs/log.txt'))

pprint.pprint(Settings().__dict__)

@attrs.define
class Application:
    """Producer for Avro using settings for authentication.

    Summary:
        Producer for Avro using settings for authentication.

    Attributes:
        producer: SerializingProducer
        schema_registry_client: SchemaRegistryClient
        admin_client: AdminClient
    """
    producer: SerializingProducer
    
    schema_registry_client: SchemaRegistryClient = attrs.field(factory=lambda: SchemaRegistryClient({
        'url': Settings.schema_registry_url,
        'basic.auth.user.info': Settings.schema_registry_auth_info,
        'cache.capacity': 0,
        'cache.latest.ttl.seconds': 0
    }))

    admin_client: AdminClient = attrs.field(factory=lambda: AdminClient({
        'bootstrap.servers': Settings.kafka_bootstrap_servers,
        'security.protocol': Settings.kafka_security_protocol,
        'sasl.mechanism': Settings.kafka_sasl_mechanism,
        'sasl.username': Settings.kafka_sasl_username,
        'sasl.password': Settings.kafka_sasl_password
    }))

    input_schema: AvroModel = None
    output_schema: AvroModel = None

    def __init__(self, input_schema: AvroModel = None, output_schema: AvroModel = None):
        """Initialize the client with optional Avro schemas for input and output.

        Args:
            input_schema (AvroModel, optional): Avro schema for input data.
            output_schema (AvroModel, optional): Avro schema for output data.
        """
        self.input_schema = input_schema if input_schema is not None else AvroModel()
        self.output_schema = output_schema if output_schema is not None else AvroModel()

        self.producer = SerializingProducer({
            'bootstrap.servers': Settings.kafka_bootstrap_servers,
            'security.protocol': Settings.kafka_security_protocol,
            'sasl.mechanism': Settings.kafka_sasl_mechanism,
            'sasl.username': Settings.kafka_sasl_username,
            'sasl.password': Settings.kafka_sasl_password,
            'statistics.interval.ms': 10 * 1000, # 10 seconds
            'stats_cb': lambda stats: logger.info(stats),
            'error_cb': lambda err: logger.error(err),
            'group.id': 'tradesignals-io',
            'enable.auto.commit': True,
            'auto.commit.interval.ms': 1 * 100, # 0.10 seconds
            'auto.offset.reset': 'earliest',
            'key.serializer': StringSerializer('utf_8'),
            'value.serializer': AvroSerializer(self.schema_registry_client, self.output_schema.schema)
        })

# @attrs.define(frozen=True)
# class KafkaProducer:
#     """Producer for Kafka using settings for authentication.
    
#     Summary:
#         Producer for Kafka using settings for authentication.

#     Attributes:
#         producer: Producer

#     Methods:
#         produce(self, streaming_model: streaming_data) -> None:
#             Produce messages to Kafka using model settings.
#     """
#     producer: Producer = attrs.field(factory=lambda: Producer({
#         'bootstrap.servers': KafkaSettings.bootstrap_servers,
#         'security.protocol': KafkaSettings.security_protocol,
#         'sasl.mechanism': KafkaSettings.sasl_mechanism,
#         'sasl.username': KafkaSettings.sasl_username,
#         'sasl.password': KafkaSettings.sasl_password
#     }))

# @attrs.define(frozen=True)
# class KafkaConsumer:
#     """Consumer for Kafka using settings for authentication.
    
#     Summary:
#         Consumer for Kafka using settings for authentication.

#     Attributes:
#         consumer: Consumer

#     Methods:
#         consume(self, streaming_model: streaming_data) -> None:
#             Consume messages from Kafka using model settings.
#     """
#     consumer: Consumer = attrs.field(factory=lambda: Consumer({
#         'bootstrap.servers': KafkaSettings.bootstrap_servers,
#         'security.protocol': KafkaSettings.security_protocol,
#         'sasl.mechanism': KafkaSettings.sasl_mechanism,
#         'sasl.username': KafkaSettings.sasl_username,
#         'sasl.password': KafkaSettings.sasl_password,
#         'group.id': 'example_group'
#     }))

# @attrs.define(frozen=True)
# class KafkaAdminClient:
#     """Admin client for Kafka using settings for authentication.
    
#     Summary:
#         Admin client for Kafka using settings for authentication.

#     Attributes:
#         admin_client: AdminClient

#     Methods:
#         create_topic(self, streaming_model: streaming_data) -> None:
#             Create a Kafka topic using model settings.
#     """
#     admin_client: AdminClient = attrs.field(factory=lambda: AdminClient({
#         'bootstrap.servers': KafkaSettings.bootstrap_servers,
#         'security.protocol': KafkaSettings.security_protocol,
#         'sasl.mechanism': KafkaSettings.sasl_mechanism,
#         'sasl.username': KafkaSettings.sasl_username,
#         'sasl.password': KafkaSettings.sasl_password
#     }))

#     def create_topic(self, streaming_model: streaming_data) -> None:
#         """Create a Kafka topic using model settings.
        
#         Summary:
#             Create a Kafka topic using model settings.

#         Args:
#             streaming_model (streaming_data): Streaming model settings.
#         """
#         topic_config = {
#             'topic': streaming_model.StreamingSettings.kafka_topic,
#             'num_partitions': streaming_model.StreamingSettings.kafka_num_partitions,
#             'replication_factor': streaming_model.StreamingSettings.kafka_replication_factor,
#             'config': {
#                 'min.insync.replicas': streaming_model.StreamingSettings.kafka_min_insync_replicas,
#                 'cleanup.policy': streaming_model.StreamingSettings.kafka_cleanup_policy,
#                 'retention.ms': streaming_model.StreamingSettings.kafka_retention_ms,
#                 'retention.bytes': streaming_model.StreamingSettings.kafka_retention_bytes
#             }
#         }
#         new_topic = NewTopic(**topic_config)
#         self.admin_client.create_topics([new_topic])

#     def create_kafka_topic(self, broker: str, topic_name: str, num_partitions: int = 1, replication_factor: int = 1):
#         """Create a Kafka topic using Kafka Admin Client.
        
#         Summary:
#             Create a Kafka topic using Kafka Admin Client.

#         Args:
#             broker (str): Kafka broker address (e.g., "localhost:9092").
#             topic_name (str): Name of the topic to create.
#             num_partitions (int): Number of partitions for the topic.
#             replication_factor (int): Replication factor for the topic.
        
#         Raises:
#             KafkaException: If topic creation fails.
#         """
#         admin_client = AdminClient({"bootstrap.servers": broker})
#         new_topic = NewTopic(topic=topic_name, num_partitions=num_partitions, replication_factor=replication_factor)
#         try:
#             fs = admin_client.create_topics([new_topic])
#             for topic, f in fs.items():
#                 f.result()  # Trigger exception if failed
#                 print(f"Topic '{topic}' created successfully.")
#         except KafkaException as e:
#             print(f"Failed to create topic '{topic_name}': {e}")
#         except Exception as ex:
#             print(f"Unexpected error while creating topic '{topic_name}': {ex}")

# @attrs.define(frozen=True)
# class SchemaRegistryClient:
#     """Client for managing schemas in Kafka's Schema Registry.
    
#     Summary:
#         Client for managing schemas in Kafka's Schema Registry.

#     Attributes:
#         schema_registry_client: SchemaRegistryClient

#     Methods:
#         register_schema(self, streaming_model: streaming_data) -> None:
#             Register schema using model settings.
#     """
#     schema_registry_client: SchemaRegistryClient = attrs.field(factory=lambda: SchemaRegistryClient({
#         'url': KafkaSettings.schema_registry_url,
#         'auth': KafkaSettings.schema_registry_auth_info
#     }))

#     def register_schema(self, streaming_model: streaming_data) -> None:
#         """Register schema using model settings."""
#         schema = streaming_model.StreamingModelSettings.avro_schema
#         schema_subject = f"{streaming_model.StreamingSettings.kafka_topic}-value"
#         self.schema_registry_client.register(schema_subject, schema)

if __name__ == "__main__":
    print(Settings)
